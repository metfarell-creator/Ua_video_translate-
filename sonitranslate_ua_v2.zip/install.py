#!/usr/bin/env python3
import sys, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / "venv"
REQ  = ROOT / "requirements.txt"

def sh(args):
    subprocess.check_call(args)

print("🔧 Створюємо venv …")
if not VENV.exists():
    sh([sys.executable, "-m", "venv", str(VENV)])

py = VENV / ("Scripts/python.exe" if (VENV / "Scripts").exists() else "bin/python")

print("📦 Встановлюємо пакети …")
sh([str(py), "-m", "pip", "install", "--upgrade", "pip"])
sh([str(py), "-m", "pip", "install", "-r", str(REQ)])

print("✅ Готово! Запуск: python run.py")
