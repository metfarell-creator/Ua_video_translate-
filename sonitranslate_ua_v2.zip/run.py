#!/usr/bin/env python3
import sys, os, platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BIN  = ROOT / "bin"
if BIN.exists():
    os.environ["PATH"] = str(BIN) + os.pathsep + os.environ.get("PATH", "")

if (ROOT / "venv" / "Scripts").exists():
    py = ROOT / "venv" / "Scripts" / "python.exe"
else:
    py = ROOT / "venv" / "bin" / "python"

if not py.exists():
    print("❌ venv не знайдено. Спочатку запустіть: python install.py")
    sys.exit(1)

import subprocess
subprocess.check_call([str(py), "-m", "ui.gradio_interface"])
