
import gradio as gr
from pathlib import Path
import config.settings as config
from pipeline.audio_processor import AudioProcessor
from pipeline.transcriber import Transcriber
from pipeline.tts_engine import UkrainianTTSEngine
from pipeline.video_mixer import VideoMixer
from pipeline.srt_utils import parse_srt_text, to_srt_text
from pipeline.accentor import stress_text, stress_segments
from pipeline.timing import timefit_segments

class App:
    def __init__(self):
        self.ap = AudioProcessor()
        self.tr = Transcriber()
        self.tts = UkrainianTTSEngine()
        self.mix = VideoMixer()

    # ---------- AUTODUB WORKFLOW (Transcribe -> Stress -> TTS -> Align -> Mix) ----------
    def autodub(self, video, yt_url, voice_opt, voice_ref, add_stress, diarize, hf_token, diffusion_steps, embedding_scale, replace_on_video):
        # 1. get audio
        if yt_url and yt_url.strip():
            audio = self.ap.download_yt(yt_url.strip())
            is_video = False
            video_path = None
            total_dur = self.ap.duration(audio)
        else:
            if video is None:
                raise gr.Error("Додайте відео-файл або YouTube URL.")
            video_path = Path(video.name)
            audio = self.ap.extract(video_path)
            is_video = True
            total_dur = self.ap.duration(audio)

        # 2. transcription (+ optional diarization)
        segs = self.tr(str(audio), diarize=bool(diarize), hf_token=(hf_token or None))

        # 3. optional stress accents
        if add_stress:
            segs = stress_segments(segs)

        # 4. TTS
        texts = [s["text"] for s in segs]
        ref_path = Path(voice_ref.name) if (voice_opt == "Клонування" and voice_ref) else None
        wavs  = self.tts.batch(texts, config.TEMP_DIR / "tts",
                               ref=ref_path,
                               diffusion_steps=int(diffusion_steps),
                               embedding_scale=float(embedding_scale))

        # Attach generated wav paths back to segments
        for w, s in zip(wavs, segs):
            s["path"] = w

        # 5. WSOLA/phase-vocoder time-fit to segment durations
        segs = timefit_segments(segs, sr=config.SAMPLE_RATE)

        # 6. Assemble the final track on a silent canvas
        merged = config.TEMP_DIR / "final.wav"
        self.ap.merge(segs, merged, total_dur)

        # 7. Output
        if replace_on_video and is_video and video_path:
            final_video = config.TEMP_DIR / "dubbed.mp4"
            self.mix.replace_audio(video_path, merged, final_video)
            return str(final_video), str(merged)
        # return audio only
        return None, str(merged)

    # ---------- SRT WORKFLOW (Edit -> Stress -> TTS -> Align -> Mix) ----------
    def load_srt_file(self, srt_file):
        if srt_file is None:
            return "", gr.update(visible=False), []
        txt = Path(srt_file.name).read_text(encoding="utf-8", errors="ignore")
        segs = parse_srt_text(txt)
        # Prepare a simple table [start, end, text]
        table = [[s["start"], s["end"], s["text"]] for s in segs]
        return txt, gr.update(visible=True), table

    def add_stress_to_srt(self, srt_text):
        segs = parse_srt_text(srt_text or "")
        segs = stress_segments(segs)
        return to_srt_text(segs)

    def synth_from_srt(self, srt_text, voice_opt, voice_ref, diffusion_steps, embedding_scale, upload_video):
        segs = parse_srt_text(srt_text or "")
        total_dur = max([s["end"] for s in segs], default=0.0)
        if len(segs) == 0:
            raise gr.Error("Додайте або завантажте SRT.")

        # TTS
        ref_path = Path(voice_ref.name) if (voice_opt == "Клонування" and voice_ref) else None
        texts = [s["text"] for s in segs]
        wavs = self.tts.batch(texts, config.TEMP_DIR / "tts_srt",
                              ref=ref_path,
                              diffusion_steps=int(diffusion_steps),
                              embedding_scale=float(embedding_scale))
        for w, s in zip(wavs, segs):
            s["path"] = w

        # Time-fit each segment to its window
        segs = timefit_segments(segs, sr=config.SAMPLE_RATE)

        # Merge to one wav
        merged = config.TEMP_DIR / "final_from_srt.wav"
        self.ap.merge(segs, merged, total_dur)

        # Optionally replace audio on uploaded video
        if upload_video is not None:
            video_path = Path(upload_video.name)
            final_video = config.TEMP_DIR / "dubbed_from_srt.mp4"
            self.mix.replace_audio(video_path, merged, final_video)
            return str(final_video), str(merged)
        return None, str(merged)

    def gui(self):
        with gr.Blocks(theme=config.GRADIO_THEME, title="SoniTranslate-UA") as demo:
            gr.Markdown("### 🎧 Портативний дублер відео українською (StyleTTS2) — з акцентатором, редактором SRT та діаризацією")

            with gr.Tab("Автодубляж (транскрипція)"):
                with gr.Row():
                    vid = gr.File(label="Відео файл", file_types=[".mp4", ".avi", ".mov", ".mkv"])
                    yt  = gr.Textbox(label="або YouTube URL")

                with gr.Row():
                    vopt = gr.Radio(choices=["Стандартний", "Клонування"], value="Стандартний", label="Голос")
                    vref = gr.File(label="Зразок голосу (10–20 с)", file_types=[".wav", ".mp3"], visible=False)
                vopt.change(lambda x: gr.update(visible=(x == "Клонування")), vopt, vref)

                with gr.Accordion("Налаштування", open=False):
                    add_stress = gr.Checkbox(label="Додавати наголоси до транскрипції", value=True)
                    diarize = gr.Checkbox(label="Діаризація (розпізнання спікерів)", value=False)
                    hf_token = gr.Textbox(label="HuggingFace token (для діаризації)", type="password", visible=True)
                    diffusion_steps = gr.Slider(1, 10, value=5, step=1, label="Diffusion steps (TTS)")
                    embedding_scale = gr.Slider(0.5, 2.0, value=1.0, step=0.1, label="Embedding scale (TTS)")
                    replace_on_video = gr.Checkbox(label="Відразу замінити аудіо у відео", value=True)

                out_video = gr.File(label="Готове відео", visible=True)
                out_audio = gr.Audio(label="Згенерована аудіодоріжка (прослухати/завантажити)", type="filepath")

                btn = gr.Button("🎯 Дублювати", variant="primary")
                btn.click(self.autodub,
                          inputs=[vid, yt, vopt, vref, add_stress, diarize, hf_token, diffusion_steps, embedding_scale, replace_on_video],
                          outputs=[out_video, out_audio])

            with gr.Tab("SRT → Озвучка"):
                with gr.Row():
                    srt_file = gr.File(label="Завантажити SRT", file_types=[".srt"])
                    video_for_srt = gr.File(label="(Опц.) Відео для заміни доріжки", file_types=[".mp4", ".avi", ".mov", ".mkv"])

                srt_text = gr.Textbox(label="Або вставте SRT тут", lines=12)
                srt_table = gr.Dataframe(headers=["start", "end", "text"], datatype=["number","number","str"], label="Попередній перегляд", visible=False)

                with gr.Row():
                    add_stress_btn = gr.Button("Додати наголоси в SRT")
                    synth_btn = gr.Button("Синтезувати з SRT", variant="primary")

                with gr.Row():
                    vopt2 = gr.Radio(choices=["Стандартний", "Клонування"], value="Стандартний", label="Голос")
                    vref2 = gr.File(label="Зразок голосу (10–20 с)", file_types=[".wav", ".mp3"], visible=False)
                vopt2.change(lambda x: gr.update(visible=(x == "Клонування")), vopt2, vref2)

                with gr.Accordion("Параметри TTS", open=False):
                    diffusion_steps2 = gr.Slider(1, 10, value=5, step=1, label="Diffusion steps (TTS)")
                    embedding_scale2 = gr.Slider(0.5, 2.0, value=1.0, step=0.1, label="Embedding scale (TTS)")

                out_video2 = gr.File(label="Готове відео", visible=True)
                out_audio2 = gr.Audio(label="Згенерована аудіодоріжка (прослухати/завантажити)", type="filepath")

                # Callbacks
                srt_file.change(self.load_srt_file, inputs=[srt_file], outputs=[srt_text, srt_table, srt_table])
                add_stress_btn.click(self.add_stress_to_srt, inputs=[srt_text], outputs=[srt_text])
                synth_btn.click(self.synth_from_srt,
                                inputs=[srt_text, vopt2, vref2, diffusion_steps2, embedding_scale2, video_for_srt],
                                outputs=[out_video2, out_audio2])

        demo.launch(server_name="0.0.0.0", server_port=7860, share=False)

if __name__ == "__main__":
    App().gui()
