import whisperx, torch
import config.settings as config

class Transcriber:
    def __init__(self):
        self.model = None
        self.align_model = None
        self.meta = None

    def load(self):
        if self.model:
            return
        self.model = whisperx.load_model(
            config.WHISPER_MODEL,
            config.WHISPER_DEVICE,
            compute_type=config.WHISPER_COMPUTE_T,
            language=config.TARGET_LANG,
        )
        self.align_model, self.meta = whisperx.load_align_model(
            language_code=config.TARGET_LANG,
            device=config.WHISPER_DEVICE,
        )

    def __call__(self, audio: str, diarize: bool = False, hf_token: str | None = None):
        self.load()
        result = self.model.transcribe(audio, batch_size=config.BATCH_SIZE)
        result = whisperx.align(
            result["segments"], self.align_model, self.meta, audio,
            config.WHISPER_DEVICE, return_char_alignments=False
        )
        if diarize and hf_token:
            diarize_model = whisperx.DiarizationPipeline(
                use_auth_token=hf_token, device=config.WHISPER_DEVICE
            )
            diz = diarize_model(audio)
            result = whisperx.assign_word_speakers(diz, result)
        return result["segments"]

    def cleanup(self):
        self.model = None
        self.align_model = None
        try:
            torch.cuda.empty_cache()
        except Exception:
            pass
