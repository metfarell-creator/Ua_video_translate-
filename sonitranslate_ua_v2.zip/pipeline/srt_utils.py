
from typing import List, Dict
import srt
from datetime import timedelta

def parse_srt_text(srt_text: str) -> List[Dict]:
    """Парсинг SRT у список сегментів {start, end, text}"""
    subs = list(srt.parse(srt_text or ""))
    segs = []
    for sub in subs:
        start = sub.start.total_seconds()
        end = sub.end.total_seconds()
        segs.append({"start": start, "end": end, "text": sub.content})
    return segs

def to_srt_text(segs: List[Dict]) -> str:
    """Серіалізація сегментів назад у SRT"""
    items = []
    for i, s in enumerate(segs, 1):
        start = timedelta(seconds=float(s["start"]))
        end = timedelta(seconds=float(s["end"]))
        items.append(srt.Subtitle(index=i, start=start, end=end, content=str(s["text"])))
    return srt.compose(items)
