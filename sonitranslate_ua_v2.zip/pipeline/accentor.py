
from typing import List, Dict
try:
    from ukrainian_word_stress import Stressifier, StressSymbol
    _stressifier = Stressifier()
    _stress_symbol = getattr(StressSymbol, "ACUTE", None) or getattr(StressSymbol, "DEFAULT", None)
except Exception:
    _stressifier = None
    _stress_symbol = None

def stress_text(text: str) -> str:
    """
    Додає наголоси в українському тексті.
    Якщо бібліотека недоступна — повертає текст без змін.
    """
    if not text:
        return text
    if _stressifier is None:
        return text
    try:
        # деякі версії приймають stress_symbol, інші — ні
        try:
            return _stressifier.put_stress(text, stress_symbol=_stress_symbol)
        except TypeError:
            return _stressifier.put_stress(text)
    except Exception:
        return text

def stress_segments(segs: List[Dict]) -> List[Dict]:
    out = []
    for s in segs:
        ss = dict(s)
        ss["text"] = stress_text(s.get("text", ""))
        out.append(ss)
    return out
