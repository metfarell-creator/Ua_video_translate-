import torch, torchaudio, tempfile
from pathlib import Path
import config.settings as config

# Підтримуємо обидві можливі реалізації інференсу
StyleTTS2Model = None
try:
    from styletts2_inference.models import StyleTTS2 as _StyleTTS2
    StyleTTS2Model = _StyleTTS2
except Exception:
    try:
        from styletts2 import StyleTTS2 as _StyleTTS2
        StyleTTS2Model = _StyleTTS2
    except Exception:
        StyleTTS2Model = None

class UkrainianTTSEngine:
    def __init__(self):
        self.model = None

    def load(self):
        if self.model:
            return
        cfg = config.STYLETTS2_CONFIG
        if not cfg["checkpoint_path"].exists():
            raise FileNotFoundError(f"Не знайдено чекпойнт: {cfg['checkpoint_path']}")
        if StyleTTS2Model is None:
            raise ImportError("Не вдалося імпортувати StyleTTS2. Перевірте залежності або додайте інференс-модуль.")
        self.model = StyleTTS2Model(
            model_checkpoint_path=str(cfg["checkpoint_path"]),
            config_path=str(cfg["model_path"]),
            device=cfg["device"],
        )

    def synthesize(self, text: str, out: Path | None = None, ref: Path | None = None,
                   diffusion_steps: int = 5, embedding_scale: float = 1.0) -> Path:
        self.load()
        out = out or Path(tempfile.mktemp(suffix=".wav"))
        wav = self.model.inference(
            text,
            target_voice_path=str(ref) if ref else None,
            diffusion_steps=diffusion_steps,
            embedding_scale=embedding_scale,
        )
        if not isinstance(wav, torch.Tensor):
            wav = torch.tensor(wav, dtype=torch.float32)
        if wav.dim() == 1:
            wav = wav.unsqueeze(0)  # [1, T]
        torchaudio.save(str(out), wav, config.SAMPLE_RATE)
        return out

    def batch(self, texts, outdir: Path, ref: Path | None = None,
              diffusion_steps: int = 5, embedding_scale: float = 1.0):
        outdir.mkdir(parents=True, exist_ok=True)
        outs = []
        for i, t in enumerate(texts):
            p = outdir / f"{i:04d}.wav"
            outs.append(self.synthesize(t, p, ref, diffusion_steps, embedding_scale))
        return outs
