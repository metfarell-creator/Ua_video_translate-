
from typing import List, Dict
import numpy as np
import soundfile as sf
import librosa
from pathlib import Path

def _load_mono(path: Path, target_sr: int) -> tuple[np.ndarray, int]:
    y, sr = sf.read(str(path))
    if y.ndim > 1:
        y = y[:, 0]
    if sr != target_sr:
        y = librosa.resample(y, orig_sr=sr, target_sr=target_sr)
        sr = target_sr
    return y.astype(np.float32), sr

def _save_wav(path: Path, y: np.ndarray, sr: int):
    sf.write(str(path), y, sr)

def timefit_file(in_path: Path, out_path: Path, target_duration: float, sr: int) -> Path:
    """
    Масштабує трек у часі до target_duration із збереженням тону (phase vocoder).
    """
    y, _ = _load_mono(in_path, target_sr=sr)
    L = max(len(y) / sr, 1e-3)
    rate = L / max(target_duration, 1e-3)
    # librosa: rate>1 -> швидше -> коротше
    y2 = librosa.effects.time_stretch(y, rate=rate)
    # М'які поля спереду/заду, щоб уникати клацань
    head = int(0.070 * sr)   # 70ms
    tail = int(0.120 * sr)   # 120ms
    y2 = np.concatenate([np.zeros(head, dtype=np.float32), y2, np.zeros(tail, dtype=np.float32)], axis=0)
    _save_wav(out_path, y2, sr)
    return out_path

def timefit_segments(seg_files: List[Dict], sr: int) -> List[Dict]:
    """
    Для кожного сегмента приводить длительность озвучки до (end-start),
    повертає оновлений список з path на нові файли.
    """
    out = []
    for s in seg_files:
        target = float(s["end"]) - float(s["start"])
        inp = Path(s["path"])
        newp = inp.with_name(inp.stem + "_fit.wav")
        timefit_file(inp, newp, target_duration=target, sr=sr)
        ss = dict(s)
        ss["path"] = newp
        out.append(ss)
    return out
