import ffmpeg, yt_dlp
from pathlib import Path
from pydub import AudioSegment
import librosa

import config.settings as config

class AudioProcessor:
    def __init__(self):
        self.tmp = config.TEMP_DIR

    # ---------- YOUTUBE ----------
    def download_yt(self, url: str, out: Path | None = None) -> Path:
        out = out or self.tmp / "yt.wav"
        base = out.with_suffix("")
        ydl = {
            "format": "bestaudio/best",
            "outtmpl": str(base),
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "wav",
                "preferredquality": "192"
            }],
        }
        with yt_dlp.YoutubeDL(ydl) as y:
            y.download([url])
        # yt-dlp створить base + '.wav'
        return base.with_suffix(".wav")

    # ---------- EXTRACT ----------
    def extract(self, video: Path, out: Path | None = None) -> Path:
        out = out or self.tmp / "extracted.wav"
        (
            ffmpeg
            .input(str(video))
            .output(str(out), ac=1, ar=16000)
            .overwrite_output()
            .run(quiet=True)
        )
        return out

    # ---------- DURATION ----------
    def duration(self, p: Path) -> float:
        return float(librosa.get_duration(path=str(p)))

    # ---------- MERGE (place segments on a silent canvas) ----------
    def merge(self, seg_files: list[dict], out: Path, total_duration: float) -> Path:
        canvas = AudioSegment.silent(duration=int(total_duration * 1000))
        for s in seg_files:
            snd = AudioSegment.from_file(s["path"])
            canvas = canvas.overlay(snd, position=int(s["start"] * 1000))
        canvas.export(out, format="wav")
        return out
