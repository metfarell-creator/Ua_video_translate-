
import ffmpeg
from pathlib import Path
import config.settings as config

class VideoMixer:
    def __init__(self):
        self.tmp = config.TEMP_DIR

    def replace_audio(self, video: Path, audio: Path, out: Path) -> Path:
        tmp_aac = self.tmp / "tmp.aac"
        (
            ffmpeg
            .input(str(audio))
            .output(str(tmp_aac), ac=2, ar=44100, acodec="aac")
            .overwrite_output()
            .run(quiet=True)
        )
        (
            ffmpeg
            .input(str(video))
            .input(str(tmp_aac))
            .output(str(out), vcodec="copy", acodec="aac")
            .global_args("-map", "0:v:0", "-map", "1:a:0", "-shortest")
            .overwrite_output()
            .run(quiet=True)
        )
        try:
            tmp_aac.unlink()
        except Exception:
            pass
        return out

    def _srt_time(self, s: float) -> str:
        hh = int(s // 3600)
        mm = int((s % 3600) // 60)
        ss = int(s % 60)
        ms = int((s % 1) * 1000)
        return f"{hh:02d}:{mm:02d}:{ss:02d},{ms:03d}"
