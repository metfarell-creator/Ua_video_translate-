import torch
from pathlib import Path

BASE_DIR   = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"
TEMP_DIR   = BASE_DIR / "temp"
EXAMPLES   = BASE_DIR / "examples"

# створюємо недостаючі папки
for d in (MODELS_DIR, TEMP_DIR, EXAMPLES, MODELS_DIR / "styletts2_ua"):
    d.mkdir(parents=True, exist_ok=True)

# ---------- WHISPER ----------
WHISPER_MODEL      = "large-v2"
WHISPER_DEVICE     = "cuda" if torch.cuda.is_available() else "cpu"
WHISPER_COMPUTE_T  = "float16" if WHISPER_DEVICE == "cuda" else "int8"
BATCH_SIZE         = 4

# ---------- STYLETTS2 ----------
STYLETTS2_CONFIG = {
    "model_path":      MODELS_DIR / "styletts2_ua" / "config.yml",
    "checkpoint_path": MODELS_DIR / "styletts2_ua" / "epochs_2nd_00020.pth",
    "device":          WHISPER_DEVICE
}
SAMPLE_RATE        = 24_000
TARGET_LANG        = "uk"

# ---------- GRADIO ----------
GRADIO_THEME       = "soft"


# ---------- TIMING / ALIGNMENT ----------
HEAD_PAD_MS          = 70
TAIL_PAD_MS          = 120
SAMPLE_RATE          = 24_000  # перенесено вище, залишаємо для узгодженості
FIXED_SPEECH_RATE    = 1.0
MIN_GAP_MS           = 80
